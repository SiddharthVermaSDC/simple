﻿using Food_For_You.Services.IdentityAPI.Models.Dto;

namespace Food_For_You.Services.IdentityAPI.Service.IService
{
    public interface IIdentityService
    {
        Task<string> Register(RegistrationRequestDto registrationRequestDto);
        Task<LoginResponseDto> Login(LoginRequestDto loginRequestDto);
        Task<bool> AssignRole(string email, string roleName);
    }
}
