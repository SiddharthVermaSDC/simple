﻿using Food_For_You.Services.IdentityAPI.Models;

namespace Food_For_You.Services.IdentityAPI.Service.IService

{
    public interface IJwtTokenGenrator
    {
        string GenerateToken(ApplicationUser applicationUser, IEnumerable<string> roles);
    }
}
