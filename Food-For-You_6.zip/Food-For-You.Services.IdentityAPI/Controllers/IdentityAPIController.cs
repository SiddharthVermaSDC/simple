﻿using Food_For_You.Services.IdentityAPI.Models.Dto;
using Food_For_You.Services.IdentityAPI.Service.IService;
using Microsoft.AspNetCore.Mvc;

namespace Food_For_You.Services.IdentityAPI.Controllers
{
   
    [Route("api/identity")]
    [ApiController]
    public class IdentityAPIController : ControllerBase
    {
        private readonly IIdentityService _identityService;
        protected ResponseDto _response;
        public IdentityAPIController(IIdentityService identityService)
        {
            _identityService = identityService;
            _response = new();
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegistrationRequestDto model)
        {
            var errorMessage = await _identityService.Register(model);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                _response.IsSuccess = false;
                _response.Message = errorMessage;
                return BadRequest(_response);
            }
            return Ok(_response);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto model)
        {
            var loginResponse = await _identityService.Login(model);
            if (loginResponse.User == null)
            {
                _response.IsSuccess = false;
                _response.Message = "Username or Password is incorrect";
                return BadRequest(_response);
            }
            _response.Result = loginResponse;
            return Ok(_response);
        }

        [HttpPost("AssignRole")]
        public async Task<IActionResult> AssignRole([FromBody] RegistrationRequestDto model)
        {
            var assignRoleSuccessfull = await _identityService.AssignRole(model.Email, model.Role.ToUpper());
            if (!assignRoleSuccessfull)
            {
                _response.IsSuccess = false;
                _response.Message = "Error Occured!";
                return BadRequest(_response);
            }

            return Ok(_response);
        }
    }
}
