﻿using Microsoft.AspNetCore.Identity;

namespace Food_For_You.Services.IdentityAPI.Models
{
    public class ApplicationUser :IdentityUser
    {
        public string Name { get; set; }
    }
}
