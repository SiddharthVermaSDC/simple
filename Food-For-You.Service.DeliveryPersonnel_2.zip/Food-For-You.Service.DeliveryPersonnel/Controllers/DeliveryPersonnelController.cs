﻿using Microsoft.AspNetCore.Mvc;
using Food_For_You.Service.DeliveryPersonnel.Models.Dto;
using AutoMapper;
using Food_For_You.Service.DeliveryPersonnel.Data;
using Food_For_You.Service.DeliveryPersonnel.Models;

namespace Food_For_You.Service.DeliveryPersonnel.Controllers
{
    [Route("api/delivery")]
    [ApiController]
    public class DeliveryPersonnelController : ControllerBase
    {
        protected ResponseDto _response;

        private IMapper _mapper;

        private readonly AppDbContext _db;
        public DeliveryPersonnelController(AppDbContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
            _response = new ResponseDto();
        }

        [HttpGet("GetDeliveryBoy/{PinCode:int}")]
        public ResponseDto GetDeliveryBoy(int PinCode)
        {
            try
            {
                DeliveryBoy obj = _db.DeliveryBoy.First(u => u.PinCode == PinCode);
                _response.Result = _mapper.Map<DeliveryBoyDto>(obj);

            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpGet("GetAllDeliveryBoy")]
        public ResponseDto GetAllDeliveryBoy()
        {
            try
            {
                IEnumerable<DeliveryBoy> objList = _db.DeliveryBoy.ToList();
                _response.Result = _mapper.Map<IEnumerable<DeliveryBoyDto>>(objList);

            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpPost("DeliveryBoyCreate")]
        // [Authorize(Roles = "ADMIN")]
        public ResponseDto DeliveryBoyCreate([FromBody] DeliveryBoyDto deliveryBoyDto)
        {
            try
            {
                DeliveryBoy obj = _mapper.Map<DeliveryBoy>(deliveryBoyDto);
                _db.DeliveryBoy.Add(obj);
                _db.SaveChanges();
                _response.Result = _mapper.Map<DeliveryBoyDto>(obj);
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpPut("DeliveryBoyUpdate")]
        //   [Authorize(Roles = "ADMIN")]
        public ResponseDto Update([FromBody] DeliveryBoyDto deliveryBoyDto)
        {
            try
            {
                DeliveryBoy obj = _mapper.Map<DeliveryBoy>(deliveryBoyDto);
                _db.DeliveryBoy.Update(obj);
                _db.SaveChanges();
                _response.Result = _mapper.Map<DeliveryBoyDto>(obj);
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpDelete]
        [Route("{id:int}")]
        //    [Authorize(Roles = "ADMIN")]
        public ResponseDto Delete(int id)
        {
            try
            {
                DeliveryBoy obj = _db.DeliveryBoy.First(u => u.Id == id);
                _db.DeliveryBoy.Remove(obj);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }
    }
}
