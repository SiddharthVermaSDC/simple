﻿using AutoMapper;
using Food_For_You.Service.DeliveryPersonnel.Models.Dto;
using Food_For_You.Service.DeliveryPersonnel.Models;

namespace Food_For_You.Service.DeliveryPersonnel
{
    public class MappingConfig
    {
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
              //  config.CreateMap<Cart, CartDto>().ReverseMap();
                config.CreateMap<DeliveryBoy, DeliveryBoyDto>().ReverseMap();
            });
            return mappingConfig;
        }
    }
}
