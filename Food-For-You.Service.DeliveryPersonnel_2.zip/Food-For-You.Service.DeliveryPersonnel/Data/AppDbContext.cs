﻿using Food_For_You.Service.DeliveryPersonnel.Models;
using Microsoft.EntityFrameworkCore;

namespace Food_For_You.Service.DeliveryPersonnel.Data
{
    public class AppDbContext:DbContext
    {
        public AppDbContext (DbContextOptions<AppDbContext> options) : base(options)
        { 

        }
        public DbSet<DeliveryBoy> DeliveryBoy { get; set; }
    }
}
