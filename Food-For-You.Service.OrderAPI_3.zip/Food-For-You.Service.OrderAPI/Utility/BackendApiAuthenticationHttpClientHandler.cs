﻿using Microsoft.AspNetCore.Authentication;
using System.Net.Http.Headers;

namespace Food_For_You.Service.OrderAPI.Utility
{
    public class BackendApiAuthenticationHttpClientHandler : DelegatingHandler
    {
        // Delegating handler are kind of similar to Dotnet Core Middleware,but the main
        // difference is that delegating handler are on client side
        // if you are making HTTP request using HTTP client then we can use delegating handler
        // to pass bearer token to other request

        private readonly IHttpContextAccessor _accessor;

        public BackendApiAuthenticationHttpClientHandler(IHttpContextAccessor accessor)
        {
            _accessor= accessor;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken cancellationToken)
        {
            var token = await _accessor.HttpContext.GetTokenAsync("access_token");

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await base.SendAsync(request,cancellationToken);
        }
    }
}
