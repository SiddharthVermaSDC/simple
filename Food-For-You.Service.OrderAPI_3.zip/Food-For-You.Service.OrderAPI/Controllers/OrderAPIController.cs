﻿using AutoMapper;
using Food_For_You.Service.OrderAPI.Data;
using Food_For_You.Service.OrderAPI.Models;
using Food_For_You.Service.OrderAPI.Models.Dto;
using Food_For_You.Service.OrderAPI.Service.IService;
using Food_For_You.Services.OrderAPI.Utility;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using Stripe;
using System.Security.AccessControl;

namespace Food_For_You.Service.OrderAPI.Controllers
{
    [Route("api/order")]
    [ApiController]
    public class OrderAPIController : ControllerBase
    {
        private ResDto _res;

        private IMapper _mapper;

        private readonly AppDbContext _db;

        private IDeliveryService _deliveryService;

        public OrderAPIController(IMapper mapper, AppDbContext db,IDeliveryService deliveryService)
        {
            _res = new ResDto();
            _mapper = mapper;
            _db = db;
            _deliveryService = deliveryService;
        }

      //  [Authorize]
        [HttpGet("GetOrders")]

        public async Task<ResDto>? Get(string? userId = "")
        {
            try
            {
                IEnumerable<OrderHeader> objList;
                if(User.IsInRole(SD.RoleAdmin))
                {
                    objList= _db.OrderHeaders.Include(u => u.orderDetails).OrderByDescending(u => u.OrderHeaderId).ToList();
                }
                else
                {
                    objList = _db.OrderHeaders.Include(u => u.orderDetails).Where(u=>u.UserId== userId).OrderByDescending(u => u.OrderHeaderId).ToList();
                }
                _res.Result = _mapper.Map<IEnumerable<OrderHeaderDto>>(objList);
            }
            catch (Exception ex)
            {
                _res.IsSuccess = false;
                _res.Message = ex.Message;
            }
            return _res;
        }

    //    [Authorize]
        [HttpGet("GetOrder/{id:int}")]
        public ResDto? Get(int id)
        {
            try
            {
                OrderHeader orderHeader = _db.OrderHeaders.Include(u => u.orderDetails).First(u => u.OrderHeaderId == id);
                _res.Result=_mapper.Map<OrderHeaderDto>(orderHeader);
            }
            catch (Exception ex)
            {
                _res.IsSuccess = false;
                _res.Message = ex.Message;
            }
            return _res;
        }

        [HttpPost("CreateOrder")]
        //   [Authorize]
        public async Task<ResDto> CreateOrder([FromBody] CartDto cartDto)
        {
            try
            {
                DeliveryBoyDto deliveryBoy = await _deliveryService.GetDeliveryBoys(221007);

                if (deliveryBoy == null)
                {
                    return _res;
                }
                else
                {
                    OrderHeaderDto orderHeaderDto = _mapper.Map<OrderHeaderDto>(cartDto.CartHeader);
                    orderHeaderDto.fk_deliveryId = deliveryBoy.Id;
                    orderHeaderDto.OrderTime = DateTime.Now;
                    orderHeaderDto.Status = SD.Status_Preparing;
                    orderHeaderDto.orderDetails = _mapper.Map<IEnumerable<OrderDetailsDto>>(cartDto.CartDetails);

                    OrderHeader ordercreated = _db.OrderHeaders.Add(_mapper.Map<OrderHeader>(orderHeaderDto)).Entity;
                    await _db.SaveChangesAsync();

                    orderHeaderDto.OrderHeaderId = ordercreated.OrderHeaderId;
                    _res.Result = orderHeaderDto;
                }


            }
            catch (Exception ex)
            {
                _res.IsSuccess = false;
                _res.Message = ex.Message;
            }
            return _res;
        }

        [HttpPost("UpdateOrderStatus/{orderId:int}")]
        //   [Authorize]
        public async Task<ResDto> UpdateOrderStatus(int orderId,[FromBody] string newStatus)
        {
            try
            {
                OrderHeader orderHeader = _db.OrderHeaders.First(u => u.OrderHeaderId == orderId);
                if(newStatus==SD.Status_Cancelled)
                {
                    var options = new RefundCreateOptions
                    {
                        Reason = RefundReasons.RequestedByCustomer
                    };
                    orderHeader.Status = newStatus;
                    _db.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                _res.IsSuccess=false;
            }
            return _res;   
        }
    }
}
