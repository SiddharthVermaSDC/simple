﻿namespace Food_For_You.Service.OrderAPI.Models.Dto
{
    public class ResDto
    {
        public object? Result { get; set; }

        public bool IsSuccess { get; set; } = true;

        public string Message { get; set; } = "";
    }
}
