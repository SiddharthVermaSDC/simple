﻿namespace Food_For_You.Service.OrderAPI.Models.Dto
{
    public class OrderHeaderDto
    {
        public int OrderHeaderId { get; set; }
        public string? UserId { get; set; }
        public int RestaurantId { get; set; }
        public double OrderTotal { get; set; }
        public string? Name { get; set; }
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public DateTime OrderTime { get; set; }
        public string? Status { get; set; }
        public int fk_deliveryId { get; set; }
        public IEnumerable<OrderDetailsDto> orderDetails { get; set; }
    }
}
