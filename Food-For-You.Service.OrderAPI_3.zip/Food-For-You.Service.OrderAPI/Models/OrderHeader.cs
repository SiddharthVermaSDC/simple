﻿using System.ComponentModel.DataAnnotations;

namespace Food_For_You.Service.OrderAPI.Models
{
    public class OrderHeader
    {
        [Key]
        [Required]
        public int OrderHeaderId { get; set; }
        [Required]
        public string UserId { get; set; }
        [Required]
        public int RestaurantId { get; set; }
        public double OrderTotal { get; set; }
        [Required]
        public string? Name { get; set; }
        [Required]
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public DateTime OrderTime { get; set; }
        public string? Status { get; set; }
        public int fk_deliveryId { get; set; }
        public IEnumerable<OrderDetails> orderDetails { get; set; } 
    }
}
