﻿using Food_For_You.Service.OrderAPI.Models.Dto;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Food_For_You.Service.OrderAPI.Models
{
    // one orderheader can have multiple order details
    public class OrderDetails
    {
        [Key]
        [Required]
        public int OrderDetailsId { get; set; }
        [Required]
        public int OrderHeaderId { get; set; }
        [ForeignKey("OrderHeaderId")]
        [NotMapped]
        public OrderHeader? OrderHeader { get; set; }
        [Required]
        public int ProductId { get; set; }
        [NotMapped]
        public ProductDto? Product { get; set; }
        public int Count { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }
    }
}
