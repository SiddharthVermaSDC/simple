﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Food_For_You.Service.OrderAPI.Migrations
{
    /// <inheritdoc />
    public partial class UpdateOrderHeaderTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "RestaurantId",
                table: "OrderHeaders",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "fk_deliveryId",
                table: "OrderHeaders",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "fk_deliveryId",
                table: "OrderHeaders");

            migrationBuilder.AlterColumn<string>(
                name: "RestaurantId",
                table: "OrderHeaders",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");
        }
    }
}
