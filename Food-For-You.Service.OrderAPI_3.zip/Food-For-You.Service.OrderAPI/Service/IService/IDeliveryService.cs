﻿using Food_For_You.Service.OrderAPI.Models.Dto;

namespace Food_For_You.Service.OrderAPI.Service.IService
{
    // Responsible to Load all Delivery Boy from DelieveryPartner API
    public interface IDeliveryService
    {
        Task<DeliveryBoyDto> GetDeliveryBoys(int pincode);
    }
}
