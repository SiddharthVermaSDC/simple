﻿using Food_For_You.Service.OrderAPI.Models.Dto;
using Food_For_You.Service.OrderAPI.Service.IService;
using Newtonsoft.Json;

namespace Food_For_You.Service.OrderAPI.Service
{
    public class DeliveryService : IDeliveryService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public DeliveryService(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<DeliveryBoyDto> GetDeliveryBoys(int pincode)
        {
            var client = _httpClientFactory.CreateClient("Delivery"); // it will get the base address

            var response = await client.GetAsync($"/api/delivery/{pincode}");

            var apiContent = await response.Content.ReadAsStringAsync(); // Serialize httpcontent to string

            var resp = JsonConvert.DeserializeObject<ResDto>(apiContent);

            if (resp.IsSuccess)
            {
                return JsonConvert.DeserializeObject<DeliveryBoyDto>(Convert.ToString(resp.Result));
            }
            return new DeliveryBoyDto();
        }
    }
}
