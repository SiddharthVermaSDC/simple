﻿using AutoMapper;
using Food_For_You.Service.CartAPI.Models;
using Food_For_You.Service.CartAPI.Models.Dto;
using Food_For_You.Services.CartAPI.Models;

namespace Food_For_You.Service.CartAPI
{
    public class MappingConfig
    {
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
              //  config.CreateMap<Cart, CartDto>().ReverseMap();
                config.CreateMap<CartHeader, CartHeaderDto>().ReverseMap();
                config.CreateMap<CartDetails, CartDetailsDto>().ReverseMap();
            });
            return mappingConfig;
        }
    }
}
