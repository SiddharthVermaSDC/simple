﻿using Food_For_You.Service.CartAPI.Models.Dto;

namespace Food_For_You.Service.CartAPI.Service.IService
{
    public interface IProductService
    {
        Task<IEnumerable<ProductDto>> GetProducts();
    }
}
