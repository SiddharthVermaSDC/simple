﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Food_For_You.Service.CartAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddDbToCartDetails : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "RestaurantId",
                table: "CartDetails",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RestaurantId",
                table: "CartDetails");
        }
    }
}
