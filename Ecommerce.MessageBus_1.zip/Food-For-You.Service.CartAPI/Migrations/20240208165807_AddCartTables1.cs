﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Food_For_You.Service.CartAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddCartTables1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CouponCode",
                table: "CartHeaders");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CouponCode",
                table: "CartHeaders",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
