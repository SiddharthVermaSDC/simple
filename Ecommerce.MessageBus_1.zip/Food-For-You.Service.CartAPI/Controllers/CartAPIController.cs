﻿using AutoMapper;
using Food_For_You.Service.CartAPI.Data;
using Food_For_You.Service.CartAPI.Models.Dto;
using Food_For_You.Service.CartAPI.Service.IService;
using Food_For_You.Services.CartAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Food_For_You.Service.CartAPI.Controllers
{
    [Route("api/cart")]
    [ApiController]
    public class CartAPIController : ControllerBase
    {
        private readonly AppDbContext _db;
        private ResponseDto _response;
        private IMapper _mapper;
        private IProductService _productService;
        // private readonly IMessageBus _messageBus;
        private IConfiguration _configuration;

        public CartAPIController(AppDbContext db, IMapper mapper, IProductService product,
            // IMessageBus messageBus, 
            IConfiguration configuration)
        {
            _db = db;
            _productService = product;
            _mapper = mapper;
            _response = new ResponseDto();
            //  _messageBus = messageBus;
            _configuration = configuration;
        }

        [HttpGet("GetCart/{userId}")]
        public async Task<ResponseDto> GetCart(string userId)
        {
            try
            {
                CartDto cart = new()
                {
                    CartHeader = _mapper.Map<CartHeaderDto>(_db.CartHeaders.First(u => u.UserId == userId))
                };
                cart.CartDetails = _mapper.Map<IEnumerable<CartDetailsDto>>(_db.CartDetails.
                    Where(u => u.CartHeaderId == cart.CartHeader.CartHeaderID));

                IEnumerable<ProductDto> productDtos = await _productService.GetProducts();

                foreach (var item in cart.CartDetails)
                {
                    item.Product = productDtos.FirstOrDefault(u => u.ProductId == item.ProductId);
                    //    cart.CartHeader.CartTotal += (item.Count * item.Product.Price);
                    item.CartHeader.CartTotal += (item.Count * item.Product.Price);
                }

                _response.Result = cart;
            }
            catch (Exception Ex)
            {
                _response.Message = Ex.Message.ToString();
                _response.IsSuccess = false;
            }
            return _response;
        }

        [HttpPost("CartUpsert")]
        public async Task<ResponseDto> CartUpsert(CartDto cartDto)
        {
            try
            {
                var cartHeaderFromDb = await _db.CartHeaders.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == cartDto.CartHeader.UserId);
                if (cartHeaderFromDb == null)
                {
                    // create header and details
                    CartHeader cartHeader = _mapper.Map<CartHeader>(cartDto.CartHeader);
                    _db.CartHeaders.Add(cartHeader);
                    await _db.SaveChangesAsync();
                    cartDto.CartDetails.First().CartHeaderId = cartHeader.CartHeaderID;
                    _db.CartDetails.Add(_mapper.Map<CartDetails>(cartDto.CartDetails.First()));
                    await _db.SaveChangesAsync();
                }
                else
                {
                    // if header is not null
                    //check if details has same product
                    var cartDetailsFromDb = await _db.CartDetails.AsNoTracking().FirstOrDefaultAsync(
                        u => u.ProductId == cartDto.CartDetails.First().ProductId &&
                        u.CartHeaderId == cartHeaderFromDb.CartHeaderID);
                    if (cartDetailsFromDb == null)
                    {

                        // Create Cart Details
                        cartDto.CartDetails.First().CartHeaderId = cartHeaderFromDb.CartHeaderID;
                        _db.CartDetails.Add(_mapper.Map<CartDetails>(cartDto.CartDetails.First()));
                        await _db.SaveChangesAsync();
                    }
                    else
                    {
                        // Update count in cart
                        cartDto.CartDetails.First().Count += cartDetailsFromDb.Count;
                        cartDto.CartDetails.First().CartHeaderId = cartDetailsFromDb.CartHeaderId;
                        cartDto.CartDetails.First().CartDetailsId = cartDetailsFromDb.CartDetailsId;
                        _db.CartDetails.Update(_mapper.Map<CartDetails>(cartDto.CartDetails.First()));
                        await _db.SaveChangesAsync();
                    }
                }
                _response.Result = cartDto;
            }
            catch (Exception Ex)
            {
                _response.Message = Ex.Message.ToString();
                _response.IsSuccess = false;
            }
            return _response;
        }

        [HttpDelete("RemoveCartItem/{cartDetailsId}")]
        public async Task<ResponseDto> RemoveCartItem(int cartDetailsId)
        {
            try
            {
                CartDetails cartDetails = _db.CartDetails.First(u => u.CartDetailsId == cartDetailsId);
                int totalCountofCartItem = _db.CartDetails.Where(u => u.CartHeaderId == cartDetails.CartHeaderId).Count();
                _db.CartDetails.Remove(cartDetails);
                if (totalCountofCartItem == 1)
                {
                    // create header and details
                    var cartHeaderToRemove = await _db.CartHeaders.FirstOrDefaultAsync(u => u.CartHeaderID == cartDetails.CartHeaderId);
                    _db.CartHeaders.Remove(cartHeaderToRemove);

                }
                await _db.SaveChangesAsync();
                _response.Result = true;
            }
            catch (Exception Ex)
            {
                _response.Message = Ex.Message.ToString();
                _response.IsSuccess = false;
            }
            return _response;
        }

        [HttpDelete("RemoveAllItem/{userId}")]
        public async Task<ResponseDto> RemoveAllItem(string userId)
        {
            try
            {
                CartHeader cart = _db.CartHeaders.First(u => u.UserId == userId);
                IEnumerable<CartDetails> cartDetails = _db.CartDetails.Where(u => u.CartHeaderId == cart.CartHeaderID).ToList();
                //   int totalCountofCartItem = _db.CartDetails.Where(u => u.CartHeaderId == cartDetails.CartHeaderId).Count();

                foreach (var item in cartDetails)
                {
                    _db.CartDetails.Remove(item);
                }
                var cartHeaderToRemove = await _db.CartHeaders.FirstOrDefaultAsync(u => u.UserId == userId);
                _db.CartHeaders.Remove(cartHeaderToRemove);
                await _db.SaveChangesAsync();
                _response.Result = true;
            }
            catch (Exception Ex)
            {
                _response.Message = Ex.Message.ToString();
                _response.IsSuccess = false;
            }
            return _response;
        }

    }
}
