﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Food_For_You.Services.CartAPI.Models
{
    public class CartHeader
    {
        [Key]
        public int CartHeaderID { get; set; }
        public string? UserId { get; set; }
        [Required]
        public int RestaurantId { get; set; }
        [NotMapped] 
        public double CartTotal { get; set; }
    }
}
