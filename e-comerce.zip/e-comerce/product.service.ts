import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../app.url';
import { Observable, map, take } from 'rxjs';
import { IProduct } from '../Models/app-product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
   constructor(private http: HttpClient) { }
   // get all product
   getProductById(Pk_RestaurantId:any) {
    return this.http.get(`${environment.ProductAPI}`);
   }

    // Get Product based on product id
    GetProductById(productId:any):Observable<IProduct> {
    debugger;
   // const url = `${environment.ProductAPI}GetProductById`;
   // return this.http.get<IProduct>(`${environment.ProductAPI}${fk_RestaurantId}`);
    return this.http.get<IProduct>(`${environment.ProductAPI}GetProductById/${productId}`);
  }

   editProduct(productModel: any) : Observable<IProduct> {
    debugger;
    const url = `${environment.ProductAPI}ProductUpdate`;
      return this.http.post<IProduct>(url,productModel).pipe(map(x=>x),take(1));
    }

  deleteProduct(pK_ProductId: any) : Observable<IProduct> {
    debugger;
    const url = `${environment.ProductAPI}`;

    return this.http.delete<IProduct>(`${environment.ProductAPI}${pK_ProductId}`);
  }

  // Get Product based on restaurant
  getProductByRestaurantId(fk_RestaurantId:any):Observable<IProduct> {
    debugger;
    const url = `${environment.ProductAPI}GetProductByRestaurant`;
   // return this.http.get<IProduct>(`${environment.ProductAPI}${fk_RestaurantId}`);
    return this.http.get<IProduct>(`${environment.ProductAPI}GetProductByRestaurant/${fk_RestaurantId}`);
  }

}
