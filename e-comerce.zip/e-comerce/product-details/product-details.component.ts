import { Component } from '@angular/core';
import { ProductService } from '../../Shared/Services/product.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {
  products: any[] = [];
  private _unsubscribeAll: Array<Subscription> = [];

  constructor(
    public productService: ProductService
  ) {}

 
}
