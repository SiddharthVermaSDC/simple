﻿using AutoMapper;
using Food_For_You.Services.ProductAPI.Models;
using Food_For_You.Services.ProductAPI.Models.Dto;

namespace Food_For_You.Services.ProductAPI
{
    public class MappingConfig
    {
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<ProductDto, Product>();
                config.CreateMap<Product, ProductDto>();
            });
            return mappingConfig;
        }
    }
}
