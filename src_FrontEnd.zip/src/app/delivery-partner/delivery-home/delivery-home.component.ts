import { Component } from '@angular/core';

@Component({
  selector: 'app-delivery-home',
  templateUrl: './delivery-home.component.html',
  styleUrl: './delivery-home.component.css'
})
export class DeliveryHomeComponent {
RoleTypeFromDelivert:string="DELIVERY";
RoleToRegister?:string;

onClick()
{
  this.RoleToRegister=this.RoleTypeFromDelivert
}
}
