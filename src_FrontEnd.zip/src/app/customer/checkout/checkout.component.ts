import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';
import { CartService } from '../../Shared/Services/cart.service';
import { ToastrService } from 'ngx-toastr';
import { ICartDto } from '../../Shared/Models/app-CartDto';
import { OrderService } from '../../Shared/Services/order.service';
import { IOrderDetails } from '../../Shared/Models/app-OrderDetails';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css',
})
export class CheckoutComponent {
  public productList: any = [];
  public grantTotal: number = 0;
  UserId = localStorage.getItem('userId');
  Name = localStorage.getItem('Name');
  EmailId = localStorage.getItem('EmailId');
  PhoneNumber = localStorage.getItem('PhoneNumber');
  private _unsubscribeAll: Array<Subscription> = [];
   cartModel: ICartDto= <ICartDto>{};
   orderDetails: IOrderDetails= <IOrderDetails>{};
  
  constructor(
    private cartSerivce: CartService,
    private tostar: ToastrService,
    private orderService: OrderService
  ) {}
  ngOnInit(): void {
    debugger;
    this.cartSerivce
      .GetCartDetailsByUser(this.UserId)
      .subscribe((response: any) => {
        if (response && response.result) {
          debugger;
          this.productList = response.result.cartDetails;
          this.grantTotal = this.getTotalPrice();
        }
      });
  }
  getTotalPrice(): number {
    debugger;
    let grandTotal = 0;
    this.productList.forEach(
      (element: { cartHeader: any; cartTotal: number }) => {
        grandTotal += element.cartHeader.cartTotal;
      }
    );
    return grandTotal;
  }
 
  checkout() {
    debugger;
    console.log(this.productList);
   //this.cartModel.cartHeader.cartTotal=this.grantTotal;
    const combinedData = {
      CartHeader: this.productList.map((cartItem:any) => ({
        CartHeaderId: cartItem.cartHeader.cartHeaderID,
        UserId:this.UserId,
        Name:this.Name,
        Phone:this.PhoneNumber,
        Email:this.EmailId,
        RestaurantId:cartItem.cartHeader.restaurantId,
        // ProductName: cartItem.product.name,
        // ProductId:cartItem.product.productId
    })),
      CartDetails: this.productList.map((cartItem:any) => ({
        CartDetailsId:cartItem.cartDetailsId,
        CartHeaderId:cartItem.cartHeaderId,
        ProductName: cartItem.product.name,
        ProductId:cartItem.product.productId,
        Price:cartItem.product.price,
        Count:cartItem.count,
        CartTotal: cartItem.cartHeader.cartTotal,
    })),
    };
  //   const value = Checkoutform.value;
  //   this.cartModel.cartHeader.cartHeaderID = value.cartHeaderID;
  //   this.cartModel.cartHeader.userId = value.userId;
  //   this.cartModel.cartHeader.cartTotal = value.cartTotal;
  //   this.cartModel.cartHeader.restaurantId = value.restaurantId;
  //   this.cartModel.cartHeader.customerName = value.firstName;
  //   this.cartModel.cartHeader.email = value.email;
  //   this.cartModel.cartHeader.phone = value.phone;
  //  // for(let i=this.cartModel.cartDetails?.length;)
  //  for (const property in this.cartModel.cartDetails)
  //  console.log(property); 
    // for (let value of this.cartModel.cartDetails) {
    //   console.log(value); 	//10 20 30
    // }
    // this.productList.forEach((element: { cartModel: { cartDetails: { count: number | undefined; }; }; }) => {this.cartModel.cartDetails?.length
    //   this.count=element.cartModel.cartDetails.count});
   // this.cartModel.cartDetails[0].cartDetailsId=value.phone;


    this._unsubscribeAll.push(
      this.orderService.CreateOrder(combinedData).subscribe((response: any) => {
        if (response.isSuccess) {
        //  localStorage.setItem('token', response.result.token);
          this.tostar.success('You Order have been placed!');
        }
      })
    );
  }

 
}
