export interface ILoggedInUserDetails{
    userId:string,
    name:string,
    Location:string,
    role:string,
    email:string,
    phoneNumber:number;
    id:string;
    address:string;
    pinCode:string;
}