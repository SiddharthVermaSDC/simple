import { ProductDto } from "../../Models/ProductDto";
import { ICartHeaderDto } from "./app-CardHeaderDto";

export interface ICartDetailsDto {
    cartDetailsId: number;
    cartHeaderId: number;
    cartHeader: ICartHeaderDto | null;
    productId: number;
    product: ProductDto | null;
    count: number;
}