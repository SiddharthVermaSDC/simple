export interface ICartHeaderDto {
    cartHeaderID: number;
    userId: string | null;
    restaurantId:number;
    cartTotal: number;
    customerName: string | null;
    phone: string | null;
    email: string | null;
}