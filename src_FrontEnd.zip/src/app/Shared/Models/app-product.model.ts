export interface IProduct{
    productId:number;
    productName?:string;
    description?:string;
    fk_restaurantid?:number;
    price?:number;
    category?:string;
    image?:number;
    isEdit:boolean;
}