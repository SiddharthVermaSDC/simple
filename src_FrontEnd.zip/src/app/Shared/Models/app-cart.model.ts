export interface ICart {
    cartID:number
    userId :string
    productId:number
    count:number
    CartTotal:number

}