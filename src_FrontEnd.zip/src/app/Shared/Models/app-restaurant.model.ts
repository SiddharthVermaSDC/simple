export interface IRestaurant{
    PK_RestaurantId?:number;
    OwnerName?:string;
    RestaurentName?:string;
    Description?:string;
    Address?:string;
    PhoneNumber?:string;
    Rating?:number;
    FK_UserId?:string;
    ImageName?:string;
    ImageUrl?:string;
    isSelected: boolean;
    isEdit: boolean;
}
