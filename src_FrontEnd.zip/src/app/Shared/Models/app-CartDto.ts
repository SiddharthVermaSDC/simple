import { ICartDetailsDto } from "./app-CarDetailsDto";
import { ICartHeaderDto } from "./app-CardHeaderDto";

export interface ICartDto {
    cartHeader: ICartHeaderDto;
    cartDetails: ICartDetailsDto[] | null;
}