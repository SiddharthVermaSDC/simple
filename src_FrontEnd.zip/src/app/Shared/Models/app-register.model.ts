export interface IRegister{
    userName?:string;
    email?:string;
    password?:string;
    mobile?:number;
    roleType?:string;
}