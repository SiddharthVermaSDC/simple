export interface IOrderDetails{
    customerName: string | null;
    phone: string | null;
    email: string | null;
}