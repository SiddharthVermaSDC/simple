import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, map, take } from 'rxjs';
import { environment } from '../../app.url';
import { ICart } from '../Models/app-cart.model';
import { ICartDto } from '../Models/app-CartDto';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  userId=localStorage.getItem('userId');
  public cartItemList: any = [];
  public productList = new BehaviorSubject<any>([]);

  constructor(private http: HttpClient) {}
  getProduct() {
    return this.productList.asObservable();
  }
  setProduct(product: any) {
    this.cartItemList.push(...product);
    this.productList.next(product);
  }
  removeCartItem(cartDetailsId: number) {
    debugger;
    return this.http.delete<ICartDto>(
      `${environment.CartAPI}RemoveCartItem/${cartDetailsId}`
    );
  }
  removeAllCart(userId:any) {
    debugger;
    return this.http.delete<ICart>(
      `${environment.CartAPI}RemoveAllItem/${userId}`
    );
  }

  UpsertCartAsync(cartModel: any) {
    debugger;
    let data = {
      cartHeader:{
        CartHeaderID:0,
        UserId: this.userId,
        RestaurantId:cartModel.fk_RestaurantId,
        CartTotal:0
      },
      cartDetails:[
        {
          CartDetailsId: 0,
          CartHeaderId: 0,
          ProductId: cartModel.productId,
          Count: cartModel.Count
        }
      ]
    };
    return this.http.post(`${environment.CartAPI}CartUpsert`, data).pipe(
      map((x) => x),
      take(1)
    );
  }
  GetCartDetailsByUser(UserId: any): Observable<ICartDto> {
    debugger;
    // const url = `${environment.ProductAPI}GetProductById`;
    return this.http.get<ICartDto>(`${environment.CartAPI}GetCart/${UserId}`);
  }

  // UpsertCartAsync1(cartModel: any) {
  //   debugger;
  //   let data = {
  //     UserId: this.userId,
  //     ProductId: cartModel.productId,
  //     Count: cartModel.Count,
  //     CartTotal: 0,
  //     CartID: 0,
  //   };
  //   return this.http.post(`${environment.CartAPI}CartUpsert1`, data).pipe(
  //     map((x) => x),
  //     take(1)
  //   );
  // }
  // removeCartItem1(productId: number, userId: string) {
  //   debugger;
  //   return this.http.delete<ICart>(
  //     `${environment.CartAPI}RemoveCart_Product/${productId}/${userId}`
  //   );
  // }

  // addtoCart(product: any) {
  //   this.cartItemList.push(product);
  //   this.productList.next(this.cartItemList);
  //   this.getTotalPrice();
  // }
  // getTotalPrice(): number {
  //   let grandTotal = 0;
  //   this.cartItemList.map((a: any) => {
  //     grandTotal += a.total;
  //   });
  //   return grandTotal;
  // }
}
