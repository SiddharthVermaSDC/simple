import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../app.url';
import { map, take } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient) { }
 
  Register(registerModel: any) {
    let data = {
      Name: registerModel.userName,
      PhoneNumber: registerModel.mobile,
      Email: registerModel.email,
      Password: registerModel.password,
      Role:registerModel.roleType
    }
    return this.http.post(`${environment.IdentityAPI}register`, data).pipe(map(x => x), take(1));
  }
  AssignRole(registerModel: any) {
    let data = {
      Name: registerModel.userName,
      PhoneNumber: registerModel.mobile,
      Email: registerModel.email,
      Password: registerModel.password,
      Role:registerModel.roleType
    }
    return this.http.post(`${environment.IdentityAPI}AssignRole`, data).pipe(map(x => x), take(1));
  }
}
