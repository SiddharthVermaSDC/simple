import { Injectable } from '@angular/core';
import { ICartDto } from '../Models/app-CartDto';
import { environment } from '../../app.url';
import { Observable, map, take } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  http: any;
  constructor() {}
  userId = localStorage.getItem('userId');
  Name = localStorage.getItem('Name');
  EmailId = localStorage.getItem('EmailId');
  PhoneNumber = localStorage.getItem('PhoneNumber');

  CreateOrder(CartDto:any) {
    debugger;
    let data = {
      // cartHeader: {
      //   cartHeaderId: 5,
      //   userId: this.userId,
      //   cartTotal: 134,
      //   name: this.Name,
      //   phone: this.PhoneNumber,
      //   email: this.EmailId,
      //   restaurantId: CartDto.cartHeader.restaurantId,
      // },
      // cartDetails: [
      //   {
      //     cartDetailsId: 11,
      //     productId: 1,
      //     product: {
      //       name: 'Samosa',
      //       price: 15,
      //       description:
      //         'Quisque vel lacus ac magna, vehicula sagittis ut non lacus',
      //       categoryName: 'Appetizer',
      //       imageUrl: 'https://placehold.co/603x403',
      //     },
      //     count: 6,
      //   },
      // ],
      cartDetails:CartDto.CartItem,
      orderUserDetails:CartDto.OrderUserDetails
    };
    const url = `${environment.OrderAPI}createOrder`;
    return this.http.post(url,data).pipe(map(x=>x),take(1));
    // return this.http.post(`${environment.OrderAPI}CreateOrder`, data).pipe(
    //   map((x) => x),
    //   take(1)
    // );
  }

  GetAllOrder(userId: string) {
    debugger;
    return this.http.get(`${environment.OrderAPI}GetOrders/${userId}`);
  }
  GetOrder(orderId: any) {
    debugger;
    return this.http.get(`${environment.OrderAPI}GetOrder/${orderId}`);
  }

  UpdateOrderStatus(orderId: number, newStatus: string) {}
}
