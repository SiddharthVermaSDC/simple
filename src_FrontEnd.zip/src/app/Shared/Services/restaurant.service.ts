import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../app.url';
import { Observable, map, take } from 'rxjs';
import { IRestaurant } from '../Models/app-restaurant.model';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
  private finaldata = [];
   constructor(private http: HttpClient) { }

   // Get all restaurant
   getRestaurant() {
      return this.http.get(`${environment.RestaurantAPI}`);
   }

   // Add a restaurant
   addRestaurant(restaurantModel: any) {
    let data = {
      PK_RestaurantId:0,
      OwnerName: restaurantModel.OwnerName,
      RestaurentName: restaurantModel.RestaurentName,
      Description: restaurantModel.Description,
      Address: restaurantModel.Address,
      Rating: restaurantModel.Rating,
      PhoneNumber:restaurantModel.PhoneNumber,
      FK_UserId: "8af3a4ef-4142-4be0-b19e-39368df7f119",
      ImageName: "NA",
      ImageUrl: "NA"
      }
      debugger;
      const url = `${environment.RestaurantAPI}AddRestaurant`;
      return this.http.post(url,data).pipe(map(x=>x),take(1));
    //return this.http.post(`${environment.RestaurantUrl}AddRestaurant`, data).pipe(map(x => x), take(1));
  }

  editRestaurant(restaurantModel: any) : Observable<IRestaurant> {
    debugger;
    const url = `${environment.RestaurantAPI}`;
      return this.http.post<IRestaurant>(url,restaurantModel).pipe(map(x=>x),take(1));
   // return this.http.post<IRestaurant>(`${environment.RestaurantUrl}`, restaurantModel);
   // return this.http.post<IRestaurant>(`${environment.RestaurantUrl}${restaurantModel.pK_RestaurantId}`, restaurantModel);
  }

  deleteRestaurant(pK_RestaurantId: any) : Observable<IRestaurant> {
    debugger;
    const url = `${environment.RestaurantAPI}`;
    //  return this.http.delete<IRestaurant>(url,restaurantModel).pipe(map(x=>x),take(1));
   // return this.http.post<IRestaurant>(`${environment.RestaurantUrl}`, restaurantModel);
    return this.http.delete<IRestaurant>(`${environment.RestaurantAPI}${pK_RestaurantId}`);
  }
}
