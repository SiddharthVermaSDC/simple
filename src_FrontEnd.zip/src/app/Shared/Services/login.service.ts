import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../app.url';
import { BehaviorSubject, map, take } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
   constructor(private http: HttpClient) { }
 
  Login(loginModel: any) {
      let data = {
      UserName: loginModel.username,
      Password: loginModel.password
    }
    return this.http.post(`${environment.IdentityAPI}login`, data).pipe(map(x => x), take(1));
  }
}
