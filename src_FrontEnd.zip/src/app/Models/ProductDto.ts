export class ProductDto{
    ProductId?: number;
    Name!:string;
    Price!:number;
    Description!:string;
    CategoryName!:string;
    ImageUrl!:string;
    Count!:number
}