export const environment={
    "IdentityAPI" : "https://localhost:7200/api/identity/",
    "RestaurantAPI" : "https://localhost:7201/api/restaurant/",
    "CartAPI" : "https://localhost:7202/api/cart/",
    "ProductAPI":"https://localhost:7203/api/product/",
    "OrderAPI":"https://localhost:7204/api/order/"
}  
