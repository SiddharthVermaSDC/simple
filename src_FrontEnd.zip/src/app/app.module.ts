import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {NgxPaginationModule } from 'ngx-pagination'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { RestaurantCardComponent } from './restaurant/restaurant-card/restaurant-card.component';
import { RestaurantListComponent } from './restaurant/restaurant-list/restaurant-list.component';
import { RestaurantService } from './Shared/Services/restaurant.service';
import { ToastrModule,ToastrService } from 'ngx-toastr';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RestaurantHomeComponent } from './restaurant/restaurant-home/restaurant-home.component';
import { DeliveryHomeComponent } from './delivery-partner/delivery-home/delivery-home.component';
import { RestaurantAddComponent } from './restaurant/restaurant-add/restaurant-add.component';
import { RestaurantEditComponent } from './restaurant/restaurant-edit/restaurant-edit.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { Dashboard1Component } from './admin/dashboard1/dashboard1.component';
import { CustomerHomeComponent } from './customer/customer-home/customer-home.component';
import { RestaurantDashboardComponent } from './restaurant/restaurant-dashboard/restaurant-dashboard.component';
import { ProductAddComponent } from './product/product-add/product-add.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { CartComponent } from './product/cart/cart.component';
import { CheckoutComponent } from './customer/checkout/checkout.component';
import { RegisterService } from './Shared/Services/register.service';
import { ProductService } from './Shared/Services/product.service';
import { CartService } from './Shared/Services/cart.service';
import { OrderService } from './Shared/Services/order.service';
import { LoginService } from './Shared/Services/login.service';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    RestaurantCardComponent,
    RestaurantListComponent,
    RestaurantHomeComponent,
    DeliveryHomeComponent,
    RestaurantAddComponent,
    RestaurantEditComponent,
    DashboardComponent,
    Dashboard1Component,
    CustomerHomeComponent,
    RestaurantDashboardComponent,
    ProductAddComponent,
    NavbarComponent,
    ProductDetailsComponent,
    CartComponent,
    CheckoutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgxPaginationModule,
    FormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
    
  ],
  providers: [LoginService, RestaurantService,RegisterService,ProductService,CartService,OrderService, ToastrService],
  bootstrap: [AppComponent]
})
export class AppModule { }
