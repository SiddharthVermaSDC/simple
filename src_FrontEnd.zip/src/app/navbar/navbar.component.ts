import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ILoggedInUserDetails } from '../Shared/Models/app-LoggedInUser.model';
import { CartService } from '../Shared/Services/cart.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
})
export class NavbarComponent implements OnInit {
  constructor(
    private tostar: ToastrService,
    private cartService: CartService
  ) {}
  token: any;
  userName: any;
  ILoggedInUserDetails: ILoggedInUserDetails = <ILoggedInUserDetails>{};
  //public totalItem: number = 0;

  UserName: string | undefined;
  ngOnInit(): void {
    debugger;
    this.token = localStorage.getItem('token');
    this.userName = localStorage.getItem('LoggedInUser');
    this.ILoggedInUserDetails = JSON.parse(
      localStorage.getItem('LoggedInUser') || '{}'
    );
    this.UserName =
      this.ILoggedInUserDetails && this.ILoggedInUserDetails.name
        ? this.ILoggedInUserDetails.name.split(' ')[0]
        : '';
    this.cartService.getProduct().subscribe((res) => {
     // this.totalItem = res.length;
    });
  }

  onLogout() {
    debugger;
    // localStorage.removeItem('token');
    // localStorage.removeItem('LoggedInUser');
    localStorage.clear();
    localStorage.removeItem('token')
    this.tostar.success('Logout Successfully');
    this.ngOnInit();
  }
}
