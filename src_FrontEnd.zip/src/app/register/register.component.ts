import { Component, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { IRegister } from '../Shared/Models/app-register.model';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { RegisterService } from '../Shared/Services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  message: string = '';
  errorMessage: string = '';
  isLoading: boolean = false;
  registerModel: IRegister = <IRegister>{};
  private _unsubscribeAll: Array<Subscription> = [];
  constructor(
    private registerService: RegisterService,
    private http: HttpClient,
    private router: Router,
    private tostar: ToastrService
  ) {}
  onSignUp(SignUpForm: NgForm) {
    debugger;
    this.errorMessage = '';
    this.isLoading = true;
    const value = SignUpForm.value;
    this.registerModel.userName = value.userName;
    this.registerModel.mobile = value.mobile;
    this.registerModel.email = value.email;
    this.registerModel.password = value.password;
    this.registerModel.roleType = value.role;
    this._unsubscribeAll.push(
      this.registerService.Register(this.registerModel).subscribe(
        (response: any) => {
          debugger;
          if (response.isSuccess) {
            this.registerService.AssignRole(this.registerModel).subscribe(
              (response: any) => {
                this.isLoading = false;
                if (response.isSuccess) {
                  
                  // localStorage.setItem('token', response.result.token);
                  // localStorage.setItem(
                  //   'LoggedInUser',
                  //   JSON.stringify(response.result.user)
                  // );
                  this.tostar.success('Registration Successful !');
                  this.router.navigate(['login']);
                  console.log('Registration successful');
                } else {
                  this.tostar.error('Registration Failed !');
                  console.log('Registration unsuccessful');
                }
              },
              (error: any) => {
                this.isLoading = false;
                console.log(error);
                this.tostar.error(error);
                this.tostar.error('Registration Failed');
                console.log('Error status:', error.status);
                this.errorMessage =
                  error?.error?.Message || 'An unknown error occurred';
              }
            )
            
          } else {
            this.tostar.error('Registration Failed !');
            console.log('Registration unsuccessful');
          }
        },
        (error: any) => {
          this.isLoading = false;
          this.tostar.error(error);
          this.tostar.error('Registration Failed');
          this.errorMessage =
            error?.error?.Message || 'An unknown error occurred';
        }
      )
    );
  }
}
