import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ILogin } from '../Shared/Models/app-login.model';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';
import { LoginService } from '../Shared/Services/login.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  errorMessage: string ="";
  isLoading: boolean=false;
  loginModel: ILogin=<ILogin>{};

  private _unsubscribeAll:Array<Subscription>=[];
  constructor(private loginService:LoginService, private http:HttpClient, private router:Router, private tostar:ToastrService) { }

  onSubmit(Loginform: NgForm) {
    debugger;
   // const token=this.loginService.Login(Loginform.value)
    this.errorMessage = '';
    this.isLoading=true;
    const value = Loginform.value;
    this.loginModel.username = value.userName;
    this.loginModel.password = value.password;
    this._unsubscribeAll.push(
      this.loginService.Login(this.loginModel).subscribe(
          (response: any) => {
          this.isLoading=false;
          if (response.isSuccess) {
            localStorage.setItem("token",response.result.token);
            localStorage.setItem('LoggedInUser',JSON.stringify(response.result.user));
            localStorage.setItem('userId',response.result.user.id);
            localStorage.setItem('EmailId',response.result.user.email);
            localStorage.setItem('Name',response.result.user.name);
            localStorage.setItem('PhoneNumber',response.result.user.phoneNumber);
            const RoleType=(response.result.user.roleType);
            
            if(RoleType=='ADMIN')
            {
              this.router.navigate(['admin-dashboard']);
            }
            else if(RoleType=='RESTAURANT OWNER')
            {
              this.router.navigate(['restaurant-dashboard']);
            }
            else if(RoleType=='DELIVERY PARTNER')
            {
              this.router.navigate(['delivery-home']);
            }
            else{
              this.router.navigate(['customer-home']);
            }
             
            this.tostar.success('Login Successfully');
           // location.        
           // console.log("Login successful");
            
          } else {
            this.tostar.error('Login Failed');
            console.log("Login unsuccessful");
          }
        },
        (error: any) => {
          this.isLoading=false;
      //    console.log(error);
          this.tostar.error(''+error.error.message);
       //   console.log("Error status:", error.status);
       //   this.errorMessage = error?.error?.Message || 'An unknown error occurred';
        }
      )
    );
  }
  

}
