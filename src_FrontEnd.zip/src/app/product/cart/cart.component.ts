import { Component, OnInit } from '@angular/core';
import { CartService } from '../../Shared/Services/cart.service';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css',
})
export class CartComponent implements OnInit {
  public products: any = [];
  public grantTotal: number = 0;
  userId = localStorage.getItem('userId');
  private _unsubscribeAll: Array<Subscription> = [];
  constructor(
    private cartSerivce: CartService,
    private tostar: ToastrService
  ) {}
  ngOnInit(): void {
    debugger;
    this.cartSerivce
      .GetCartDetailsByUser(this.userId)
      .subscribe((response: any) => {
        if (response && response.result) {
          debugger;
          this.products = response.result.cartDetails;
          this.grantTotal = this.getTotalPrice();
        }
      });
  }

  getTotalPrice(): number {
    debugger;
    let grandTotal = 0;
    this.products.forEach((element: { cartHeader: any; cartTotal: number }) => {
      grandTotal += element.cartHeader.cartTotal;
    });
    return grandTotal;
  }

  removeItem(cartDetailsId: number) {
    debugger;
    this.cartSerivce.removeCartItem(cartDetailsId).subscribe(
      (response: any) => {
        if (response.isSuccess) {
          this.tostar.success('Item Removed From The Cart!');
          this.ngOnInit();
        } else {
          this.tostar.error('Failed');
        }
      },
      (error: any) => {
        this.tostar.error('An unknown error occurred');
      }
    );
  }
  emptyCart() {
    this.cartSerivce.removeAllCart(this.userId).subscribe(
      (response: any) => {
        if (response.isSuccess) {
          this.tostar.success('Cart Remove Successfully');
          this.ngOnInit();
        } else {
          this.tostar.error('Failed');
        }
      },
      (error: any) => {
        this.tostar.error('An unknown error occurred');
      }
    );
  }

  // getCarttDetails(productId: any) {
  //   debugger;
  //   this._unsubscribeAll.push(
  //     this.cartSerivce.GetCartDetailsByUser(productId).subscribe(
  //       (response: any) => {
  //         if (response && response.result) {
  //           debugger;
  //           this.products = response.result;
  //         } else {
  //           this.tostar.error('No Product Found!');
  //         }
  //       },
  //       (error: any) => {
  //         this.tostar.error('Error Occured!');
  //       }
  //     )
  //   );
  // }
}
