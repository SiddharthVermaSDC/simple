import { Component } from '@angular/core';
import { IRestaurant } from '../../Shared/Models/app-restaurant.model';
import { Subscription } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { RestaurantService } from '../../Shared/Services/restaurant.service';

@Component({
  selector: 'app-restaurant-add',
  templateUrl: './restaurant-add.component.html',
  styleUrl: './restaurant-add.component.css'
})
export class RestaurantAddComponent {
  message:string="";
  errorMessage: string ="";
  isLoading: boolean=false;
  restaurantModel: IRestaurant=<IRestaurant>{};
  private _unsubscribeAll:Array<Subscription>=[];
  constructor(private restaurantService:RestaurantService, private http:HttpClient, private router:Router, private tostar:ToastrService) { }
  AddRestaurants(AddRestaurantForm: NgForm) {
    debugger;
    //const token=this.restaurantService.addRestaurant(AddRestaurantForm.value)
    this.errorMessage = '';
    this.isLoading=true;
    const value = AddRestaurantForm.value;
    this.restaurantModel.OwnerName = value.OwnerName;
    this.restaurantModel.RestaurentName = value.RestaurentName;
    this.restaurantModel.Description = value.Description;
    this.restaurantModel.PhoneNumber = value.PhoneNumber;
    this.restaurantModel.Rating = value.Rating;
    this.restaurantModel.Address = value.Address;
    this.restaurantModel.FK_UserId = "8af3a4ef-4142-4be0-b19e-39368df7f119" //value.userId;
    this.restaurantModel.ImageName ="NA" //value.imageName;
    this.restaurantModel.ImageUrl = "NA"//value.imageUrl;
    this._unsubscribeAll.push(
      this.restaurantService.addRestaurant(this.restaurantModel).subscribe(
          (response: any) => {
          this.isLoading=false;
          if (response.isSuccess) {
          //  localStorage.setItem("token",response.result.userId);
           // localStorage.setItem('LoggedInUser',JSON.stringify(response.result.user.name));
          //  console.log(localStorage.getItem('LoggedInUser'));
            this.tostar.success('Restaurant Added Successfully');
            this.router.navigate(['restaurant-list']);         
            console.log("Restaurant Added Successfully");
          } else {
            this.tostar.error('Failed');
            console.log("Failed");
          }
        },
        (error: any) => {
          this.isLoading=false;
          this.tostar.error('Failed');
          this.errorMessage = error?.error?.Message || 'An unknown error occurred';
        }
      )
    );
  }
}
