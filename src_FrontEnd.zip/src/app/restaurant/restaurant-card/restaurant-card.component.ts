import { Component, Input } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProductService } from '../../Shared/Services/product.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-restaurant-card',
  templateUrl: './restaurant-card.component.html',
  styleUrl: './restaurant-card.component.css',
})
export class RestaurantCardComponent {
  @Input() restaurant: any;
  restaurantMenu:boolean=true;
  productsByRestaurant: any[] = [];
  constructor(
    private productService: ProductService,
    private router: Router,
    private tostar: ToastrService
  ) {}
  ngOnInit() {
    // this.getProductByRestaurantId();
  }
  // when customer click on details button of a restaurant tha this methid will call
  private _unsubscribeAll: Array<Subscription> = [];
  getProductByRestaurantId(Pk_RestaurantId: any) {
    debugger;
    this._unsubscribeAll.push(
      this.productService
        .getProductByRestaurantId(Pk_RestaurantId)
        .subscribe((response: any) => {
          if (response && response.result) {
            debugger;
            this.productsByRestaurant = response.result;
            this.restaurantMenu=false;
          //  this.tostar.success('Success');
          }
          else{
            this.tostar.error('No Product Found!');
          }
        },
        (error: any) => {
          this.tostar.error('Error Occured!');
        }
        )
    );
  }
}
