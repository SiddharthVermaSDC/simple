import { Component } from '@angular/core';
import { ProductService } from '../../Shared/Services/product.service';
import { Subscription } from 'rxjs';
import { IProduct } from '../../Shared/Models/app-product.model';

@Component({
  selector: 'app-restaurant-dashboard',
  templateUrl: './restaurant-dashboard.component.html',
  styleUrl: './restaurant-dashboard.component.css'
})
export class RestaurantDashboardComponent {
  title='pagination';
  page:number=1;
  count:number=0;
  tablesize:number=10;
  tablesizes:any=[5,10,15,20];
  ExisProducttList: any;
  productList: any[] = [];
  
  onTableDataChnage(event:any){
  this.page=event;
  this.getProductByRestaurantId();
  }
  onTableSizeChnage(event:any):void{
    this.tablesize=event.target.value;
    this.page=1;
    this.getProductByRestaurantId();
    }

  products: any[] = [];
  constructor(private productService: ProductService) { }
  ngOnInit() {

    this.getProductByRestaurantId();
  }
  private _unsubscribeAll: Array<Subscription> = [];
  getProductByRestaurantId() {
    debugger;
    const Pk_RestaurantId=1;
    this._unsubscribeAll.push(this.productService.getProductById(Pk_RestaurantId).subscribe(
      (response: any) => {
      if (response && response.result) {
        debugger;
        this.products = response.result;
      //  localStorage.setItem('pK_RestaurantId', response.result.pK_RestaurantId);
      }
      
    }
    ))
  }

  validateField(item: any) {
    if (item != '') {
      return false;
    } else {
      return true;
    }
  }
  validateForm(item: any) {
    if (
      item.ownerName !== '' &&
      item.restaurentName !== '' &&
      item.phoneNumber !== '' &&
      (item.rating != 0 ||item.rating != '' )  &&
      item.address !== ''
    ) {
      return false;
    } else {
      return true;
    }
  }

  onEditProduct(ProductObj: IProduct) {
    debugger;
    this.ExisProducttList = JSON.stringify(ProductObj);
    this.productList.forEach((element) => {
      element.isEdit = false;
    });
    ProductObj.isEdit = true;
  }
  updateProduct(ProductObj: IProduct) {
    debugger;
    this.productService.editProduct(ProductObj).subscribe(
      (response: any) => {
        if (response.isSuccess) {
          this.ngOnInit();
          //  this.router.navigate(['restaurant-edit']);
        } else {
          console.log('Failed');
        }
      },
      (error: any) => {
        // this.errorMessage = error?.error?.Message || 'An unknown error occurred';
      }
    );
  }
  onCancel(ProductObj: IProduct) {
    debugger;
    const existingProduct = JSON.parse(this.ExisProducttList);
    ProductObj.productName = existingProduct.name;
    ProductObj.description = existingProduct.description;
    ProductObj.price = existingProduct.price;
    ProductObj.category = existingProduct.category;
    ProductObj.image = existingProduct.image;
    ProductObj.isEdit = false;
    this.ngOnInit();
  }

  onDelete(PK_ProductId: IProduct) {
    debugger;
    this.productService.deleteProduct(PK_ProductId).subscribe(
      (response: any) => {
        if (response.isSuccess) {
          this.ngOnInit();
          // this.router.navigate(['restaurant-edit']);
        } else {
          console.log('Failed');
        }
      },
      (error: any) => {
        // this.errorMessage = error?.error?.Message || 'An unknown error occurred';
      }
    );
  }
}
