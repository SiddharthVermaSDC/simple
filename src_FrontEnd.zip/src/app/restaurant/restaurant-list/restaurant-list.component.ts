import { Component } from '@angular/core';
import { RestaurantService } from '../../Shared/Services/restaurant.service';
import { Subscription } from 'rxjs';
import { ProductService } from '../../Shared/Services/product.service';
import { Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { CartService } from '../../Shared/Services/cart.service';

@Component({
  selector: 'app-restaurant-list',
  templateUrl: './restaurant-list.component.html',
  styleUrl: './restaurant-list.component.css',
})
export class RestaurantListComponent {
  restaurantMenu: boolean = true;
  productsByRestaurant: any[] = [];
  restaurants: any[] = [];
  products: any[] = [];
  Count:number=0;
  userId=localStorage.getItem('userId');

  constructor(
    private productService: ProductService,
    private router: Router,
    private tostar: ToastrService,
    private restaurantService: RestaurantService,
    private cartService:CartService
  ) {}

  ngOnInit() {
    this.getAllRestaurant();
   // this.productService.GetProductById()
  }

  // when customer click on details button of a restaurant tha this methid will call
  private _unsubscribeAll: Array<Subscription> = [];
  getProductByRestaurantId(Pk_RestaurantId: any) {
    debugger;
    this._unsubscribeAll.push(
      this.productService.getProductByRestaurantId(Pk_RestaurantId).subscribe(
        (response: any) => {
          if (response && response.result) {
            debugger;
            if (response.result.length > 0) {
              this.productsByRestaurant = response.result;
              this.restaurantMenu = false;
            } else {
              this.tostar.success('No item available!');
            }
          } else {
            this.tostar.error('No Product Found!');
          }
        },
        (error: any) => {
          this.tostar.error('Error Occured!');
        }
      )
    );
  }

  getAllRestaurant() {
    debugger;
    this._unsubscribeAll.push(
      this.restaurantService.getRestaurant().subscribe((response: any) => {
        if (response && response.result) {
          debugger;
          this.restaurants = response.result;
        }
      })
    );
  }

  getProductDetails(productId: any) {
    debugger;
    this._unsubscribeAll.push(
      this.productService.GetProductById(productId).subscribe(
        (response: any) => {
          if (response && response.result) {
            debugger;
            this.products = response.result;
          } else {
            this.tostar.error('No Product Found!');
          }
        },
        (error: any) => {
          this.tostar.error('Error Occured!');
        }
      )
    );
  }

  AddToCart(item: any)
  {
    if(this.userId!=null)
    {
      debugger;
      this.cartService.UpsertCartAsync(item);
      this._unsubscribeAll.push(
        this.cartService.UpsertCartAsync(item).subscribe(
          (response: any) => {
            if (response && response.result) {
              debugger;
             // this.products = response.result;
             this.tostar.success('Item has been added to the Cart');
            // this.Count=0;
            } else {
              this.tostar.error('Failed!');
            }
          },
          (error: any) => {
            this.tostar.error('Error Occured!');
          }
        )
      );
    }
    else{
      this.tostar.error('Please Login!');
      this.router.navigate(['login']);
    }
   
  }
}
