import { Component, Input } from '@angular/core';
import { RestaurantService } from '../../Shared/Services/restaurant.service';
import { Subscription } from 'rxjs';
import { IRestaurant } from '../../Shared/Models/app-restaurant.model';
import { Toast } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-restaurant-edit',
  templateUrl: './restaurant-edit.component.html',
  styleUrl: './restaurant-edit.component.css',
})
export class RestaurantEditComponent {
  restaurantList: any[] = [];
  ExistRestaurantList: any;
  restaurantModel: IRestaurant = <IRestaurant>{};
title='pagination';
page:number=1;
count:number=0;
tablesize:number=10;
tablesizes:any=[5,10,15,20];

onTableDataChnage(event:any){
this.page=event;
this.getAllRestaurant();
}
onTableSizeChnage(event:any):void{
  this.tablesize=event.target.value;
  this.page=1;
  this.getAllRestaurant();
  }


  constructor(
    private restaurantService: RestaurantService,
    private router: Router
  ) {}
  ngOnInit() {
    this.getAllRestaurant();
  }
  private _unsubscribeAll: Array<Subscription> = [];
  getAllRestaurant() {
    debugger;
    this._unsubscribeAll.push(
      this.restaurantService.getRestaurant().subscribe((response: any) => {
        if (response && response.result) {
          debugger;
          this.restaurantList = response.result;
        }
      })
    );
  }
  onEditRestaurant(RestaurantObj: IRestaurant) {
    debugger;
    this.ExistRestaurantList = JSON.stringify(RestaurantObj);
    this.restaurantList.forEach((element) => {
      element.isEdit = false;
    });
    RestaurantObj.isEdit = true;
  }
  updateRestaurant(RestaurantObj: IRestaurant) {
    debugger;
    this.restaurantService.editRestaurant(RestaurantObj).subscribe(
      (response: any) => {
        if (response.isSuccess) {
          this.ngOnInit();
          //  this.router.navigate(['restaurant-edit']);
        } else {
          console.log('Failed');
        }
      },
      (error: any) => {
        // this.errorMessage = error?.error?.Message || 'An unknown error occurred';
      }
    );
  }
  onCancel(RestaurantObj: IRestaurant) {
    debugger;
    const existingRestaurant = JSON.parse(this.ExistRestaurantList);
    RestaurantObj.OwnerName = existingRestaurant.ownerName;
    RestaurantObj.RestaurentName = existingRestaurant.restaurentName;
    RestaurantObj.Description = existingRestaurant.description;
    RestaurantObj.PhoneNumber = existingRestaurant.phoneNumber;
    RestaurantObj.Rating = existingRestaurant.rating;
    RestaurantObj.Address = existingRestaurant.address;
    RestaurantObj.ImageName = 'NA'; //value.imageName;
    RestaurantObj.ImageUrl = 'NA'; //value.imageUrl;
    RestaurantObj.isEdit = false;
    this.ngOnInit();
  }

  onDelete(PK_RestaurantId: IRestaurant) {
    debugger;
    this.restaurantService.deleteRestaurant(PK_RestaurantId).subscribe(
      (response: any) => {
        if (response.isSuccess) {
          this.ngOnInit();
          // this.router.navigate(['restaurant-edit']);
        } else {
          console.log('Failed');
        }
      },
      (error: any) => {
        // this.errorMessage = error?.error?.Message || 'An unknown error occurred';
      }
    );
  }

  validateField(item: any) {
    if (item != '') {
      return false;
    } else {
      return true;
    }
  }
  validateForm(item: any) {
    if (
      item.ownerName !== '' &&
      item.restaurentName !== '' &&
      item.phoneNumber !== '' &&
      (item.rating != 0 ||item.rating != '' )  &&
      item.address !== ''
    ) {
      return false;
    } else {
      return true;
    }
  }
}
