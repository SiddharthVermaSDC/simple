import { Component } from '@angular/core';

@Component({
  selector: 'app-restaurant-home',
  templateUrl: './restaurant-home.component.html',
  styleUrl: './restaurant-home.component.css'
})
export class RestaurantHomeComponent {
RoleType:string="RESTAURANT OWNER"
}
