import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  CustomerDiv:boolean=true;
  RestaurantDiv:boolean=false;
  OrdersDiv:boolean=false;
  @Input() data:any=''
 
  public CustomerDivFunction(){
      this.CustomerDiv=true;
      this.RestaurantDiv=false;
      this.OrdersDiv=false
      this.data
  }

  RestaurantDivFunction(){
      this.RestaurantDiv=true;
      this.CustomerDiv=false;
      this.OrdersDiv=false
  }

  OrdersDivFunction(){
      this.OrdersDiv=true;
      this.RestaurantDiv=false;
      this.CustomerDiv=false
  }
}
