import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { RestaurantListComponent } from './restaurant/restaurant-list/restaurant-list.component';
import { RestaurantHomeComponent } from './restaurant/restaurant-home/restaurant-home.component';
import { DeliveryHomeComponent } from './delivery-partner/delivery-home/delivery-home.component';
import { RestaurantAddComponent } from './restaurant/restaurant-add/restaurant-add.component';
import { RestaurantEditComponent } from './restaurant/restaurant-edit/restaurant-edit.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { Dashboard1Component } from './admin/dashboard1/dashboard1.component';
import { CustomerHomeComponent } from './customer/customer-home/customer-home.component';
import { RestaurantDashboardComponent } from './restaurant/restaurant-dashboard/restaurant-dashboard.component';
import { ProductAddComponent } from './product/product-add/product-add.component';
import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { CartComponent } from './product/cart/cart.component';
import { CheckoutComponent } from './customer/checkout/checkout.component';

const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: '', component: RestaurantListComponent },
  { path: 'admin-dashboard', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'restaurant-home', component: RestaurantHomeComponent },
  { path: 'restaurant-list', component: RestaurantListComponent },
  { path: 'restaurant-add', component: RestaurantAddComponent },
  { path: 'restaurant-edit', component: RestaurantEditComponent },
  { path: 'delivery-home', component: DeliveryHomeComponent },
  { path: 'admin-dashboard1', component: Dashboard1Component },
  { path: 'customer-home', component: CustomerHomeComponent },
  { path: 'restaurant-dashboard', component: RestaurantDashboardComponent },
  { path: 'product-add', component: ProductAddComponent },
  { path: 'product-details', component: ProductDetailsComponent },
  { path: 'cart', component: CartComponent},
  { path: 'checkout', component: CheckoutComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
