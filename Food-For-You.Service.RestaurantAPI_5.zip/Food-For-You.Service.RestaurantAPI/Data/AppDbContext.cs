﻿using Food_For_You.Service.RestaurantAPI.Models;
using Microsoft.EntityFrameworkCore;
namespace Food_For_You.Service.RestaurantAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options) { 
        
        }

        public DbSet<Restaurant> Restaurants { get; set; }  

    }
}
