﻿namespace Food_For_You.Service.RestaurantAPI.Models
{
    public class RestaurantDto
    {
        public int? PK_RestaurantId { get; set; }
        public string? OwnerName { get; set; }
        public string? RestaurentName { get; set; }
        public string? Description { get; set; }
        public string? Address { get; set; }
        public string? PhoneNumber { get; set; }
        public int? Rating { get; set; }        
        public string? FK_UserId { get; set; }
        //public UserDto? User { get; set; }
        public string? ImageName { get; set; }
        public string? ImageUrl { get; set; }
    }
}
