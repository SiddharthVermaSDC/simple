﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Food_For_You.Service.RestaurantAPI.Models
{
    public class Restaurant
    {
        [Key]
        public int PK_RestaurantId { get; set; }
        [Required]
        public string OwnerName { get; set; }
        [Required]
        public string RestaurentName { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        [Range(1, 5)]
        public int Rating { get; set; }        
        public string FK_UserId { get; set; }
        public string ImageName { get; set; }
        public string ImageUrl { get; set; }
    }
}
