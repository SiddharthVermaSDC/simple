﻿using AutoMapper;
using Food_For_You.Service.RestaurantAPI.Data;
using Food_For_You.Service.RestaurantAPI.Models;
using Food_For_You.Service.RestaurantAPI.Models.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Food_For_You.Service.RestaurantAPI.Controllers
{
    [Route("api/restaurant")]
    [ApiController]
    public class RestaurantAPIController : ControllerBase
    {
        private readonly AppDbContext _db;
        private ResponseDto _response;
        private IMapper _mapper;

        public RestaurantAPIController(AppDbContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
            _response = new ResponseDto();
        }
        [HttpGet]
        public ResponseDto Get()
        {
            try
            {
                IEnumerable<Restaurant> objList = _db.Restaurants.ToList();
                _response.Result = _mapper.Map<IEnumerable<RestaurantDto>>(objList);
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpGet]
        [Route("{id:int}")]
        public ResponseDto Get(int id)
        {
            try
            {
                Restaurant obj = _db.Restaurants.First(u => u.PK_RestaurantId == id);
                _response.Result = _mapper.Map<RestaurantDto>(obj);
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpPost("AddRestaurant")]
        //[Authorize(Roles = "ADMIN")]
        public ResponseDto Create([FromBody] RestaurantDto restaurantDto)
        {
            try
            {
                Restaurant obj = _mapper.Map<Restaurant>(restaurantDto);
                _db.Restaurants.Add(obj);
                _db.SaveChanges();
                _response.Result = _mapper.Map<RestaurantDto>(obj);
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpPost]
        //[Authorize(Roles = "ADMIN")]
        public ResponseDto Update([FromBody] RestaurantDto restaurantDto)
        {
            try
            {
                Restaurant obj = _mapper.Map<Restaurant>(restaurantDto);
                _db.Restaurants.Update(obj);
                _db.SaveChanges();
                _response.Result = _mapper.Map<RestaurantDto>(obj);
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }

        [HttpDelete]
        [Route("{id:int}")]
        //[Authorize(Roles = "ADMIN")]
        public ResponseDto Delete(int id)
        {
            try
            {
                Restaurant obj = _db.Restaurants.First(u => u.PK_RestaurantId == id);
                _db.Restaurants.Remove(obj);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }
    }
}
