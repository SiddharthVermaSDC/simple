﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Food_For_You.Service.RestaurantAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddResturantToDb1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Restaurants",
                newName: "RestaurentName");

            migrationBuilder.AddColumn<string>(
                name: "OwnerName",
                table: "Restaurants",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OwnerName",
                table: "Restaurants");

            migrationBuilder.RenameColumn(
                name: "RestaurentName",
                table: "Restaurants",
                newName: "Name");
        }
    }
}
